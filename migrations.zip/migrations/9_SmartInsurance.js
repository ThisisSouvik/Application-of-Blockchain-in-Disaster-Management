const Smartinsurance = artifacts.require("Smartinsurance");
module.exports= function (deployer){
    deployer.deploy(Smartinsurance);
}