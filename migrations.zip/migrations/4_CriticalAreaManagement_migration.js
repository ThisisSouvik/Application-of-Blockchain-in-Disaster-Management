const CriticalAreaManagement = artifacts.require("CriticalAreaManagement");
module.exports= function (deployer){
    deployer.deploy(CriticalAreaManagement);
}