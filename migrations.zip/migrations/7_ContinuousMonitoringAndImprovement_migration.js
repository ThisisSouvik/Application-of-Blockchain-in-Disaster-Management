const ContinuousMonitoringAndImprovement = artifacts.require("ContinuousMonitoringAndImprovement");
module.exports= function (deployer){
    deployer.deploy(ContinuousMonitoringAndImprovement);
}