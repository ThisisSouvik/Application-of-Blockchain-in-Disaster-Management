const MissingPeopleLog = artifacts.require("MissingPeopleLog");
module.exports= function (deployer){
    deployer.deploy(MissingPeopleLog);
}