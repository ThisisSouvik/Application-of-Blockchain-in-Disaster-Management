const RefugeeReliefCampMapping = artifacts.require("RefugeeReliefCampMapping");
module.exports= function (deployer){
    deployer.deploy(RefugeeReliefCampMapping);
}